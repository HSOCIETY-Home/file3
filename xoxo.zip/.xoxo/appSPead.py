import os
import sys
from time import sleep
from getpass import getpass
import subprocess

workDIR = "TxTxT"

def app(appinput,appicon):
    yourappp = input("Enter Your APK  >>> ")
    yourICON = input("Enter Your ICON >>> ")
    
    if not os.path.exists(yourappp):
        sys.exit("Your app Not Found ")
    else:
        os.system(f"mv {appinput} /{workDIR}")
        os.system(f"mv {appicon} /{workDIR}")


def replaceTHings():


